package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class deposit extends GenericMethod {

	WebDriver driver;

	public deposit(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	// locator for bankmanagerlogin
	By BankManagerLoginbtn = By.xpath("(//button[@class='btn btn-primary btn-lg'])[2]");
	// locator for addcustomer
	By Addcustomer = By.xpath("//button[@class='btn btn-lg tab']");
	// locator for firstname and lastname
	By firstname = By.xpath("//input[@placeholder='First Name']");
	By lastname = By.xpath("//input[@placeholder='Last Name']");
	By postcode = By.xpath("//input[@placeholder='Post Code']");
	By addcustbtn = By.xpath("//button[@type='submit']");
    // locator for openaccount
	By openaccount = By.xpath("(//button[@class='btn btn-lg tab'])[1]");
	// locator for namedrpdown
	By custnamedrpdown = By.xpath("//select[@name='userSelect']");
	By currencydrpdown = By.xpath("//select[@name='currency']");
	By processbtn = By.xpath("//button[@type='submit']");
	//locator for customerbtn
	By customersbtn = By.xpath("//button[@class='btn btn-lg tab'][2]");
	
	
	// method to click bankmanagerlogin
	public void bankmangerlogin() throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(3000);
		// driver.findElement(BankManagerLoginbtn).click();
		Click(driver.findElement(BankManagerLoginbtn));
	}

	public void addcustomer() {
		// VisibilityOfElement(Addcustomer);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		ClicableElement(driver.findElement(Addcustomer));
		Click(driver.findElement(Addcustomer));
		EnterValue(driver.findElement(firstname), "Divya");
		VisibilityOfElement(driver.findElement(firstname));
		
		EnterValue(driver.findElement(lastname), "Katakam");
		VisibilityOfElement(driver.findElement(lastname));
		
		EnterValue(driver.findElement(postcode), "505503");
		VisibilityOfElement(driver.findElement(postcode));
		Click(driver.findElement(addcustbtn));
		driver.switchTo().alert().accept();
		// Click(driver.findElement(openaccount));

	}

	public void openaccount1() throws InterruptedException {
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		Click(driver.findElement(openaccount));
		Select name = new Select(driver.findElement(custnamedrpdown));
		Thread.sleep(2000);
		name.selectByValue("6");
		Select currency = new Select(driver.findElement(currencydrpdown));
		Thread.sleep(2000);
		currency.selectByValue("Rupee");
		Click(driver.findElement(processbtn));
		driver.switchTo().alert().accept();

	}
	public void customersbtn1() {
		Click(driver.findElement(customersbtn));
	}
}



