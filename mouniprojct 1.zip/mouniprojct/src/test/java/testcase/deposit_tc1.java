package testcase;

import java.time.Duration;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pages.deposit;

public class deposit_tc1 extends testbase {
	// public static WebDriver driver = null;

	public WebDriver driver;

	@BeforeMethod
	public void launchBrowser_login() throws InterruptedException {
		logger.info("**********Started**********");
		// WebDriverManager.chromedriver().create();
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		logger.info("***********Verify Whether User Can Login To XYZ Bank**********");
		driver.get("https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login\\\\r\\\\n");
	}

	@Test
	public void customerlogin() throws InterruptedException {
		// creating object of bankmanagerlogin
		deposit d = new deposit(driver);
		d.bankmangerlogin();
		logger.info("**********login with your details**********");
		d.addcustomer();
		Thread.sleep(3000);
		d.openaccount1();
		Thread.sleep(3000);
		d.customersbtn1();
		Thread.sleep(3000);
	}

	@AfterMethod
	public void close() {
		logger.info("**********Driver Closed**********");
		driver.close();
	}
}
